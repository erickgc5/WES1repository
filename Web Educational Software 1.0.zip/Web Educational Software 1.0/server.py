from bottle import route, post, request, run, template, static_file

@route("/")
def main_page():
    return static_file("WES1.html", root=f"./")

@route("/<file_name:path>")
def static_files(file_name):
    return static_file(file_name, root=f"./")

@route("/images/<file_name:path>")
def images_files(file_name):
    return static_file(file_name, root=f"images/")

@route("/static/<file_name:path>")
def static_files(file_name):
    return static_file(file_name, root=f"static/")
    
@route("/data/<file_name:path>")
def data_files(file_name):
    return static_file(file_name, root=f"data/")
   
@route("/src/<file_name:path>")
def source_files(file_name):
    return static_file(file_name, root=f"src/")


run(host='localhost', port=8080, debug=True)
