
def convert(Tab):
    for i in range(len(Tab)):
        for j in range(1,len(Tab[0])):
            Tab[i][j]=Tab[i][j].replace('F','0')
            Tab[i][j]=Tab[i][j].replace('M','1')
            Tab[i][j]=Tab[i][j].replace('VG','3')
            Tab[i][j]=Tab[i][j].replace('G','2')        
            Tab[i][j]=Tab[i][j].replace('E','4')
    return Tab

def num2ling(x):#Function to translate from numerical values to linguistic values  
    if x == 0:
        return 'F'
    if x == 1:
        return 'M'
    if x == 2:
        return 'G'
    if x == 3:
        return 'VG'
    if x == 4:
        return 'E'


def f(Tab,l):#Function to calculate the linguistic value of the level (l is the level and Tab is the table of students vs assess per levels)
    L = ["Knowing-Remembering","Organizing-Understanding","Applying","Analyzing","Generating-Evaluating","Integrating-Creating","Overall Performance"]
    Tab = convert(Tab)
    col = L.index(l)+1#Number of the column of the input level l
    k = len(Tab)
    Tabl = [x[col] for x in Tab]#Elements of the column corresponding to level l
    S = [x[0] for x in Tab]#List of students

    #List of students satisfaying every one of the corresponding evaluations for T, I, and F.
    
    SlT0 = [s for s in S if Tabl[S.index(s)][0] == '0']
    SlT1 = [s for s in S if Tabl[S.index(s)][0] == '1']
    SlT2 = [s for s in S if Tabl[S.index(s)][0] == '2']
    SlT3 = [s for s in S if Tabl[S.index(s)][0] == '3']
    SlT4 = [s for s in S if Tabl[S.index(s)][0] == '4']

    SlI0 = [s for s in S if Tabl[S.index(s)][2] == '0']
    SlI1 = [s for s in S if Tabl[S.index(s)][2] == '1']
    SlI2 = [s for s in S if Tabl[S.index(s)][2] == '2']
    SlI3 = [s for s in S if Tabl[S.index(s)][2] == '3']
    SlI4 = [s for s in S if Tabl[S.index(s)][2] == '4']

    SlF0 = [s for s in S if Tabl[S.index(s)][4] == '0']
    SlF1 = [s for s in S if Tabl[S.index(s)][4] == '1']
    SlF2 = [s for s in S if Tabl[S.index(s)][4] == '2']
    SlF3 = [s for s in S if Tabl[S.index(s)][4] == '3']
    SlF4 = [s for s in S if Tabl[S.index(s)][4] == '4']

    #Weights of the level for every one of the possible evaluations for T, I, and F. E.g., wT is the list of weights of 'F', 'M', 'G', 'VG', and 'E' in level l and for T   

    wT = [len(SlT0)/len(S),len(SlT1)/len(S),len(SlT2)/len(S),len(SlT3)/len(S),len(SlT4)/len(S)]
    wI = [len(SlI0)/len(S),len(SlI1)/len(S),len(SlI2)/len(S),len(SlI3)/len(S),len(SlI4)/len(S)]
    wF = [len(SlF0)/len(S),len(SlF1)/len(S),len(SlF2)/len(S),len(SlF3)/len(S),len(SlF4)/len(S)]

    #Betas of T, I, F, and the aggregation of them (betaP)

    betaT = wT[0]*0+wT[1]*1+wT[2]*2+wT[3]*3+wT[4]*4
    betaI = wI[0]*0+wI[1]*1+wI[2]*2+wI[3]*3+wI[4]*4
    betaF = wF[0]*0+wF[1]*1+wF[2]*2+wF[3]*3+wF[4]*4
    betaP = (betaT+betaI+(4-betaF))/3

    #Corresponding alphas with respect to the betas

    alphaT = betaT-round(betaT)
    alphaI = betaI-round(betaI)
    alphaF = betaF-round(betaF)
    alphaP = betaP-round(betaP)

    return (num2ling(round(betaP)),alphaP)

def g(Tab,s):#Function to calculate the linguistic value of the student s.
    S = [x[0] for x in Tab]#List of students
    L = ["Knowing-Remembering","Organizing-Understanding","Applying","Analyzing","Generating-Evaluating","Integrating-Creating","Overall Performance"]#List of possible levels
    Tab = convert(Tab)
    row = S.index(s)
    TabS = Tab[row]#Elements of the column corresponding to student s
    TabS = TabS[1:len(TabS)]

    #List of levels satisfaying every one of the corresponding evaluations for T, I, and F.
    
    SlT0 = [l for l in L if TabS[L.index(l)][0] == '0']
    SlT1 = [l for l in L if TabS[L.index(l)][0] == '1']
    SlT2 = [l for l in L if TabS[L.index(l)][0] == '2']
    SlT3 = [l for l in L if TabS[L.index(l)][0] == '3']
    SlT4 = [l for l in L if TabS[L.index(l)][0] == '4']

    SlI0 = [l for l in L if TabS[L.index(l)][2] == '0']
    SlI1 = [l for l in L if TabS[L.index(l)][2] == '1']
    SlI2 = [l for l in L if TabS[L.index(l)][2] == '2']
    SlI3 = [l for l in L if TabS[L.index(l)][2] == '3']
    SlI4 = [l for l in L if TabS[L.index(l)][2] == '4']

    SlF0 = [l for l in L if TabS[L.index(l)][4] == '0']
    SlF1 = [l for l in L if TabS[L.index(l)][4] == '1']
    SlF2 = [l for l in L if TabS[L.index(l)][4] == '2']
    SlF3 = [l for l in L if TabS[L.index(l)][4] == '3']
    SlF4 = [l for l in L if TabS[L.index(l)][4] == '4']

    #Weights of the level for every one of the possible evaluations for T, I, and F. E.g., wT is the list of weights of 'F', 'M', 'G', 'VG', and 'E' in levels l and for T   

    wT = [len(SlT0)/len(L),len(SlT1)/len(L),len(SlT2)/len(L),len(SlT3)/len(L),len(SlT4)/len(L)]
    wI = [len(SlI0)/len(L),len(SlI1)/len(L),len(SlI2)/len(L),len(SlI3)/len(L),len(SlI4)/len(L)]
    wF = [len(SlF0)/len(L),len(SlF1)/len(L),len(SlF2)/len(L),len(SlF3)/len(L),len(SlF4)/len(L)]

    #Betas of T, I, F, and the aggregation of them (betaP)

    betaT = wT[0]*0+wT[1]*1+wT[2]*2+wT[3]*3+wT[4]*4
    betaI = wI[0]*0+wI[1]*1+wI[2]*2+wI[3]*3+wI[4]*4
    betaF = wF[0]*0+wF[1]*1+wF[2]*2+wF[3]*3+wF[4]*4
    betaP = (betaT+betaI+(4-betaF))/3

    #Corresponding alphas with respect to the betas

    alphaT = betaT-round(betaT)
    alphaI = betaI-round(betaI)
    alphaF = betaF-round(betaF)
    alphaP = betaP-round(betaP)

    return (num2ling(round(betaP)),alphaP)

#----------------------------------------------------------------------------------------------------------------------------------------------------------------------

def f1(Tab,l):#Function to calculate the linguistic value of the level (l is the level and Tab is the table of students vs assess per levels)
    L = ["Knowing-Remembering","Organizing-Understanding","Applying","Analyzing","Generating-Evaluating","Integrating-Creating","Overall Performance"]
    Tab = convert(Tab)
    col = L.index(l)+1#Number of the column of the input level l
    k = len(Tab)
    Tabl = [x[col] for x in Tab]#Elements of the column corresponding to level l
    S = [x[0] for x in Tab]#List of students

    #List of students satisfaying every one of the corresponding evaluations.
    
    Sl0 = [s for s in S if Tabl[S.index(s)] == '0']
    Sl1 = [s for s in S if Tabl[S.index(s)] == '1']
    Sl2 = [s for s in S if Tabl[S.index(s)] == '2']
    Sl3 = [s for s in S if Tabl[S.index(s)] == '3']
    Sl4 = [s for s in S if Tabl[S.index(s)] == '4']

    return ([Sl4,Sl3,Sl2,Sl1,Sl0])

def g1(Tab,s):#Function to calculate the linguistic value of the student s.
    S = [x[0] for x in Tab]#List of students
    L = ["Knowing-Remembering","Organizing-Understanding","Applying","Analyzing","Generating-Evaluating","Integrating-Creating","Overall Performance"]#List of possible levels
    Tab = convert(Tab)
    row = S.index(s)
    TabS = Tab[row]#Elements of the column corresponding to student s
    TabS = TabS[1:len(TabS)]

    #List of levels satisfying every one of the corresponding evaluations.
    
    Sl0 = [l for l in L if TabS[L.index(l)] == '0']
    Sl1 = [l for l in L if TabS[L.index(l)] == '1']
    Sl2 = [l for l in L if TabS[L.index(l)] == '2']
    Sl3 = [l for l in L if TabS[L.index(l)] == '3']
    Sl4 = [l for l in L if TabS[L.index(l)] == '4']

    return ([Sl4,Sl3,Sl2,Sl1,Sl0])

def SS2NN(Tab,l):
    L = ["Knowing-Remembering","Organizing-Understanding","Applying","Analyzing","Generating-Evaluating","Integrating-Creating","Overall Performance"]
    col = L.index(l)+1#Number of the column of the input level l
    k = len(Tab)
    Tabl = [x[col] for x in Tab]#Elements of the column corresponding to level l
    Tabl = [a[1:len(a)-1].split(',') for a in Tabl]
    T = [float(a[0]) for a in Tabl]
    I = [float(a[1]) for a in Tabl]
    F = [float(a[2]) for a in Tabl]
    return [sum(T)/len(T),sum(I)/len(I),sum(F)/len(F)]
    
def SS2Grey(Tab,l):
    fl = f1(Tab,l)
    nE = len(fl[0])
    nVG = len(fl[1])
    nG = len(fl[2])
    nM = len(fl[3])
    nF = len(fl[4])
    total = nE+nVG+nG+nM+nF
    LV = nE*85+nVG*75+nG*60+nM*50+nF*0
    UV = nE*100+nVG*84+nG*74+nM*59+nF*49
    LV = LV/total
    UV = UV/total
    return (LV+UV)/2

